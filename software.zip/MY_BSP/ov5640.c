#include "ov5640.h"
#include "ov5640cfg.h"
#include "ov5640af.h"			 	
#include "sccb.h"

extern uint16_t id;

const uint16_t jpeg_size_tbl[][2] = {
    { 160, 120 },  // QQVGA
    { 176, 144 },  // QCIF
    { 320, 240 },  // QVGA
    { 400, 240 },  // WQVGA
    { 352, 288 },  // CIF
};

uint8_t OV5640_WR_Reg(uint16_t reg,uint8_t data)
{
	uint8_t res=0;
	SCCB_Start(); 					
	if(SCCB_WR_Byte(OV5640_ADDR))res=1;		  
   	if(SCCB_WR_Byte(reg>>8))res=1;	
   	if(SCCB_WR_Byte(reg))res=1;			  
   	if(SCCB_WR_Byte(data))res=1; 	 
  	SCCB_Stop();	  
  	return	res;
}


uint8_t OV5640_RD_Reg(uint16_t reg)
{
	uint8_t val=0;
	SCCB_Start(); 				
	SCCB_WR_Byte(OV5640_ADDR);	
   	SCCB_WR_Byte(reg>>8);	 
  	SCCB_WR_Byte(reg);			  
	SCCB_Stop();   

	SCCB_Start();
	SCCB_WR_Byte(OV5640_ADDR|0X01);
   	val=SCCB_RD_Byte();	
  	SCCB_No_Ack();
  	SCCB_Stop();
  	return val;
}
 

uint8_t OV5640_Init(void)
{ 
	uint16_t i=0;
	uint16_t reg;

        
	OV5640_PWDN_Pin_RESET;		//POWER ON
	HAL_Delay(30);         
        
	reg=OV5640_RD_Reg(OV5640_CHIPIDH);	
	reg<<=8;
	reg|=OV5640_RD_Reg(OV5640_CHIPIDL);
	id = reg;
	if(reg!=OV5640_ID)
	{
		printf("ID: %d \r\n",reg);
		return 1;
	}  
	OV5640_WR_Reg(0x3103,0X11);	//system clock from pad, bit[1]
	OV5640_WR_Reg(0X3008,0X82);	
	HAL_Delay(10);
        
	for(i=0;i<sizeof(ov5640_init_reg_tbl)/4;i++)
	{
		OV5640_WR_Reg(ov5640_init_reg_tbl[i][0],ov5640_init_reg_tbl[i][1]);
	}  
        
	return 0x00; 	//ok
} 

void OV5640_JPEG_Mode(void) 
{
	uint16_t i=0; 

	for(i=0;i<(sizeof(OV5640_jpeg_reg_tbl)/4);i++)
	{
		OV5640_WR_Reg(OV5640_jpeg_reg_tbl[i][0],OV5640_jpeg_reg_tbl[i][1]);  
	}  
}

void OV5640_RGB565_Mode(void) 
{
	uint16_t i=0;

	for(i=0;i<(sizeof(ov5640_rgb565_reg_tbl)/4);i++)
	{
		OV5640_WR_Reg(ov5640_rgb565_reg_tbl[i][0],ov5640_rgb565_reg_tbl[i][1]); 
	} 
} 

/**
  * @brief  Set OV5640 camera Pixel Format.
  * @param  pObj  pointer to component object
  * @param  PixelFormat pixel format to be configured
  * @retval Component status
  */
int32_t OV5640_SetPixelFormat(uint32_t PixelFormat)
{

  uint32_t index;
  uint8_t tmp;
  /* Initialization sequence for JPEG format */
  static const uint16_t OV5640_PF_JPEG[][2] =
  {
    /*  SET PIXEL FORMAT: JPEG */
    {OV5640_FORMAT_CTRL00, 0x30},
    {OV5640_FORMAT_MUX_CTRL, 0x00},
  };

  /* Initialization sequence for RGB565 pixel format */
  static const uint16_t OV5640_PF_RGB565[][2] =
  {
    /*  SET PIXEL FORMAT: RGB565 */
    {OV5640_FORMAT_CTRL00, 0x6F},
    {OV5640_FORMAT_MUX_CTRL, 0x01},
  };

  /* Initialization sequence for YUV422 pixel format */
  static const uint16_t OV5640_PF_YUV422[][2] =
  {
    /*  SET PIXEL FORMAT: YUV422 */
    {OV5640_FORMAT_CTRL00, 0x30},
    {OV5640_FORMAT_MUX_CTRL, 0x00},
  };

  /* Initialization sequence for RGB888 pixel format */
  static const uint16_t OV5640_PF_RGB888[][2] =
  {
    /*  SET PIXEL FORMAT: RGB888 (RGBRGB)*/
    {OV5640_FORMAT_CTRL00, 0x23},
    {OV5640_FORMAT_MUX_CTRL, 0x01},
  };

  /* Initialization sequence for Monochrome 8bits pixel format */
  static const uint16_t OV5640_PF_Y8[][2] =
  {
    /*  SET PIXEL FORMAT: Y 8bits */
    {OV5640_FORMAT_CTRL00, 0x10},
    {OV5640_FORMAT_MUX_CTRL, 0x00},
  };

  /* Check if PixelFormat is supported */
  if ((PixelFormat != OV5640_RGB565) && (PixelFormat != OV5640_YUV422) &&
      (PixelFormat != OV5640_RGB888) && (PixelFormat != OV5640_Y8) && (PixelFormat != OV5640_JPEG))
  {
    /* Pixel format not supported */
    return 1;
  }
  else
  {
    /* Set specific parameters for each PixelFormat */
    switch (PixelFormat)
    {
      case OV5640_YUV422:
        for (index = 0; index < (sizeof(OV5640_PF_YUV422) / 4U); index++)
        {
            tmp = (uint8_t)OV5640_PF_YUV422[index][1];
            OV5640_WR_Reg(OV5640_PF_YUV422[index][0],tmp);
        }
        break;

      case OV5640_RGB888:
        for (index = 0; index < (sizeof(OV5640_PF_RGB888) / 4U); index++)
        {
        	tmp = (uint8_t)OV5640_PF_RGB888[index][1];
            OV5640_WR_Reg(OV5640_PF_RGB888[index][0],tmp);
        }
        break;

      case OV5640_Y8:
        for (index = 0; index < (sizeof(OV5640_PF_Y8) / 4U); index++)
        {
            tmp = (uint8_t)OV5640_PF_Y8[index][1];
            OV5640_WR_Reg(OV5640_PF_Y8[index][0],tmp);
        }
        break;

      case OV5640_JPEG:
        for (index = 0; index < (sizeof(OV5640_PF_JPEG) / 4U); index++)
        {
            tmp = (uint8_t)OV5640_PF_JPEG[index][1];
            OV5640_WR_Reg(OV5640_PF_JPEG[index][0],tmp);
        }
        break;

      case OV5640_RGB565:
      default:
        for (index = 0; index < (sizeof(OV5640_PF_RGB565) / 4U); index++)
        {
            tmp = (uint8_t)OV5640_PF_RGB565[index][1];
            OV5640_WR_Reg(OV5640_PF_RGB565[index][0],tmp);
        }
        break;
    }
  }
  if (PixelFormat == OV5640_JPEG)
  {
	  tmp = OV5640_RD_Reg(OV5640_TIMING_TC_REG21);
      tmp |= (1 << 5);
      OV5640_WR_Reg(OV5640_TIMING_TC_REG21, tmp);

	  tmp = OV5640_RD_Reg(OV5640_SYSREM_RESET02);
	  tmp &= ~((1 << 4) | (1 << 3) | (1 << 2));
	  OV5640_WR_Reg(OV5640_SYSREM_RESET02, tmp);

	  tmp = OV5640_RD_Reg(OV5640_CLOCK_ENABLE02);

	  tmp |= ((1 << 5) | (1 << 3));
	  OV5640_WR_Reg(OV5640_CLOCK_ENABLE02, tmp);
	  OV5640_WR_Reg(0x3002, 0x1C); // reset JFIFO, SFIFO, JPG
	  OV5640_WR_Reg(0x3006, 0x02); // enable JPEG clock (JPEG2x, JPEG)
	  OV5640_WR_Reg(0x4713, 0x03); // JPEG mode 3 (continuous streaming)
  }

  return 0;
}

/**
  * @brief  Enable DVP(Digital Video Port) Mode: Parallel Data Output
  * @param  pObj  pointer to component object
  * @retval Component status
  */
void OV5640_EnableDVPMode(void)
{
  uint32_t index;
  uint8_t tmp;

  static const uint16_t regs[10][2] =
  {
    /* Configure the IO Pad, output FREX/VSYNC/HREF/PCLK/D[9:2]/GPIO0/GPIO1 */
    {OV5640_PAD_OUTPUT_ENABLE01, 0xFF},
    {OV5640_PAD_OUTPUT_ENABLE02, 0xF3},
    {0x302e, 0x00},
    /* Unknown DVP control configuration */
    {0x471c, 0x50},
    {OV5640_MIPI_CONTROL00, 0x58},
    /* Timing configuration */
    {OV5640_SC_PLL_CONTRL0, 0x18},
    {OV5640_SC_PLL_CONTRL1, 0x41},
    {OV5640_SC_PLL_CONTRL2, 0x60},
    {OV5640_SC_PLL_CONTRL3, 0x13},
    {OV5640_SYSTEM_ROOT_DIVIDER, 0x01},
  };

  for(index=0; index < sizeof(regs) / 4U ; index++)
  {
    tmp = (uint8_t)regs[index][1];
    OV5640_WR_Reg(regs[index][0],tmp);
  }
}

/**
  * @brief  Set the camera pixel clock
  * @param  pObj  pointer to component object
  * @param  ClockValue Can be OV5640_PCLK_48M, OV5640_PCLK_24M, OV5640_PCLK_12M, OV5640_PCLK_9M
  *                    OV5640_PCLK_8M, OV5640_PCLK_7M
  * @retval Component status
  */
void OV5640_SetPCLK(uint32_t ClockValue)
{
  uint8_t tmp;

  switch (ClockValue)
  {
    case OV5640_PCLK_7M:
      tmp = 0x38;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x16;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_8M:
      tmp = 0x40;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x16;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_9M:
      tmp = 0x60;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x18;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_12M:
      tmp = 0x60;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x16;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_48M:
      tmp = 0x60;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x03;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_80M:
      tmp = 8;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x02;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
    case OV5640_PCLK_24M:
    default:
      tmp = 0x60;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL2,tmp);
      tmp = 0x13;
      OV5640_WR_Reg(OV5640_SC_PLL_CONTRL3,tmp);
      break;
  }

}

/**
  * @brief  Set MIPI VirtualChannel
  * @param  pObj  pointer to component object
  * @param  vchannel virtual channel for Mipi Mode
  * @retval Component status
  */
void OV5640_SetMIPIVirtualChannel(uint32_t vchannel)
{
    uint8_t tmp;
    tmp = OV5640_RD_Reg(0x4814);

	tmp &= ~(3 << 6);
	tmp |= (vchannel << 6);
	OV5640_WR_Reg(0x4814, tmp);
}

/**
  * @brief  Enable MIPI (Mobile Industry Processor Interface) Mode: Serial port
  * @param  pObj  pointer to component object
  * @retval Component status
  */
void OV5640_EnableMIPIMode(void)
{
  uint8_t tmp;
  uint32_t index;

  static const uint16_t regs[14][2] =
  {
    /* PAD settings */
    {OV5640_PAD_OUTPUT_ENABLE01, 0},
    {OV5640_PAD_OUTPUT_ENABLE02, 0},
    {0x302e, 0x08},
    /* Pixel clock period */
    {OV5640_PCLK_PERIOD, 0x23},
    /* Timing configuration */
    {OV5640_SC_PLL_CONTRL0, 0x18},
    {OV5640_SC_PLL_CONTRL1, 0x12},
    {OV5640_SC_PLL_CONTRL2, 0x1C},
    {OV5640_SC_PLL_CONTRL3, 0x13},
    {OV5640_SYSTEM_ROOT_DIVIDER, 0x01},
    {0x4814, 0x2a},
    {OV5640_MIPI_CTRL00, 0x24},
    {OV5640_PAD_OUTPUT_VALUE00, 0x70},
    {OV5640_MIPI_CONTROL00, 0x45},
    {OV5640_FRAME_CTRL02, 0x00},
  };

  for(index=0; index < sizeof(regs) / 4U ; index++)
  {
    tmp = (uint8_t)regs[index][1];
    OV5640_WR_Reg(regs[index][0],tmp);
  }
}

static const uint8_t OV5640_EXPOSURE_TBL[7][6] = {
    { 0x10, 0x08, 0x10, 0x08, 0x20, 0x10 },  // -3
    { 0x20, 0x18, 0x41, 0x20, 0x18, 0x10 },  // -2
    { 0x30, 0x28, 0x61, 0x30, 0x28, 0x10 },  // -1
    { 0x38, 0x30, 0x61, 0x38, 0x30, 0x10 },  //  0
    { 0x40, 0x38, 0x71, 0x40, 0x38, 0x10 },  // +1
    { 0x50, 0x48, 0x90, 0x50, 0x48, 0x20 },  // +2
    { 0x60, 0x58, 0xA0, 0x60, 0x58, 0x20 }   // +3
};


//exposure: 0 - 6,
void OV5640_Exposure(uint8_t exposure)
{

        OV5640_WR_Reg(0x3a0f,OV5640_EXPOSURE_TBL[exposure][0]); 
        OV5640_WR_Reg(0x3a10,OV5640_EXPOSURE_TBL[exposure][1]); 
        OV5640_WR_Reg(0x3a1b,OV5640_EXPOSURE_TBL[exposure][2]); 
        OV5640_WR_Reg(0x3a1e,OV5640_EXPOSURE_TBL[exposure][3]); 
        OV5640_WR_Reg(0x3a11,OV5640_EXPOSURE_TBL[exposure][4]); 
        OV5640_WR_Reg(0x3a1f,OV5640_EXPOSURE_TBL[exposure][5]); 

}

/**
  * @brief  Set the OV5640 camera Light Mode.
  * @param  pObj  pointer to component object
  * @param  Effect  Effect to be configured
  * @retval Component status
  */
void OV5640_Light_Mode(uint32_t LightMode)
{
	  uint32_t index;
	  uint8_t tmp;

	  /* OV5640 Light Mode setting */
	  static const uint16_t OV5640_LightModeAuto[][2] =
	  {
	    {OV5640_AWB_MANUAL_CONTROL, 0x00},
	    {OV5640_AWB_R_GAIN_MSB, 0x04},
	    {OV5640_AWB_R_GAIN_LSB, 0x00},
	    {OV5640_AWB_G_GAIN_MSB, 0x04},
	    {OV5640_AWB_G_GAIN_LSB, 0x00},
	    {OV5640_AWB_B_GAIN_MSB, 0x04},
	    {OV5640_AWB_B_GAIN_LSB, 0x00},
	  };

	  static const uint16_t OV5640_LightModeCloudy[][2] =
	  {
	    {OV5640_AWB_MANUAL_CONTROL, 0x01},
	    {OV5640_AWB_R_GAIN_MSB, 0x06},
	    {OV5640_AWB_R_GAIN_LSB, 0x48},
	    {OV5640_AWB_G_GAIN_MSB, 0x04},
	    {OV5640_AWB_G_GAIN_LSB, 0x00},
	    {OV5640_AWB_B_GAIN_MSB, 0x04},
	    {OV5640_AWB_B_GAIN_LSB, 0xD3},
	  };

	  static const uint16_t OV5640_LightModeOffice[][2] =
	  {
	    {OV5640_AWB_MANUAL_CONTROL, 0x01},
	    {OV5640_AWB_R_GAIN_MSB, 0x05},
	    {OV5640_AWB_R_GAIN_LSB, 0x48},
	    {OV5640_AWB_G_GAIN_MSB, 0x04},
	    {OV5640_AWB_G_GAIN_LSB, 0x00},
	    {OV5640_AWB_B_GAIN_MSB, 0x07},
	    {OV5640_AWB_B_GAIN_LSB, 0xCF},
	  };

	  static const uint16_t OV5640_LightModeHome[][2] =
	  {
	    {OV5640_AWB_MANUAL_CONTROL, 0x01},
	    {OV5640_AWB_R_GAIN_MSB, 0x04},
	    {OV5640_AWB_R_GAIN_LSB, 0x10},
	    {OV5640_AWB_G_GAIN_MSB, 0x04},
	    {OV5640_AWB_G_GAIN_LSB, 0x00},
	    {OV5640_AWB_B_GAIN_MSB, 0x08},
	    {OV5640_AWB_B_GAIN_LSB, 0xB6},
	  };

	  static const uint16_t OV5640_LightModeSunny[][2] =
	  {
	    {OV5640_AWB_MANUAL_CONTROL, 0x01},
	    {OV5640_AWB_R_GAIN_MSB, 0x06},
	    {OV5640_AWB_R_GAIN_LSB, 0x1C},
	    {OV5640_AWB_G_GAIN_MSB, 0x04},
	    {OV5640_AWB_G_GAIN_LSB, 0x00},
	    {OV5640_AWB_B_GAIN_MSB, 0x04},
	    {OV5640_AWB_B_GAIN_LSB, 0xF3},
	  };

	  tmp = 0x00;
	  OV5640_WR_Reg(OV5640_AWB_MANUAL_CONTROL,tmp);

	  tmp = 0x46;
	  OV5640_WR_Reg(OV5640_AWB_CTRL16,tmp);

	  tmp = 0xF8;
	  OV5640_WR_Reg(OV5640_AWB_CTRL17,tmp);

	  tmp = 0x04;
	  OV5640_WR_Reg(OV5640_AWB_CTRL18,tmp);

	  switch (LightMode)
	     {
	       case OV5640_LIGHT_SUNNY:
	         for (index = 0; index < (sizeof(OV5640_LightModeSunny) / 4U) ; index++)
	         {
	             tmp = (uint8_t)OV5640_LightModeSunny[index][1];
	             OV5640_WR_Reg(OV5640_LightModeSunny[index][0],tmp);
	         }
	         break;
	       case OV5640_LIGHT_OFFICE:
	         for (index = 0; index < (sizeof(OV5640_LightModeOffice) / 4U) ; index++)
	         {
	             tmp = (uint8_t)OV5640_LightModeOffice[index][1];
	             OV5640_WR_Reg(OV5640_LightModeOffice[index][0],tmp);
	         }
	         break;
	       case OV5640_LIGHT_CLOUDY:
	         for (index = 0; index < (sizeof(OV5640_LightModeCloudy) / 4U) ; index++)
	         {
	             tmp = (uint8_t)OV5640_LightModeCloudy[index][1];
	             OV5640_WR_Reg(OV5640_LightModeCloudy[index][0],tmp);
	         }
	         break;
	       case OV5640_LIGHT_HOME:
	         for (index = 0; index < (sizeof(OV5640_LightModeHome) / 4U) ; index++)
	         {
	             tmp = (uint8_t)OV5640_LightModeHome[index][1];
	             OV5640_WR_Reg(OV5640_LightModeHome[index][0],tmp);
	         }
	         break;
	       case OV5640_LIGHT_AUTO:
	       default :
	         for (index = 0; index < (sizeof(OV5640_LightModeAuto) / 4U) ; index++)
	         {
	             tmp = (uint8_t)OV5640_LightModeAuto[index][1];
	             OV5640_WR_Reg(OV5640_LightModeAuto[index][0],tmp);
	         }
	         break;
	     }
}

static const uint8_t OV5640_SATURATION_TBL[7][6] = {
    { 0x0C, 0x30, 0x3D, 0x3E, 0x3D, 0x01 },  // -3
    { 0x10, 0x3D, 0x4D, 0x4E, 0x4D, 0x01 },  // -2
    { 0x15, 0x52, 0x66, 0x68, 0x66, 0x02 },  // -1
    { 0x1A, 0x66, 0x80, 0x82, 0x80, 0x02 },  //  0
    { 0x1F, 0x7A, 0x9A, 0x9C, 0x9A, 0x02 },  // +1
    { 0x24, 0x8F, 0xB3, 0xB6, 0xB3, 0x03 },  // +2
    { 0x2B, 0xAB, 0xD6, 0xDA, 0xD6, 0x04 }   // +3
};

/**
  * @brief  Set the OV5640 camera Saturation Level.
  * @note   The color saturation of OV5640 could be adjusted. High color saturation
  *         would make the picture looks more vivid, but the side effect is the
  *         bigger noise and not accurate skin color.
  * @param  pObj  pointer to component object
  * @param  Level Value to be configured
  * @retval Component status
  */
void OV5640_Color_Saturation(uint8_t sat)
{ 
	uint8_t i;
	OV5640_WR_Reg(0x5380,0x1E);
	OV5640_WR_Reg(0x5381,0x56);
	OV5640_WR_Reg(0x5382,0x08);
	OV5640_WR_Reg(0x5383,0x0A);
	for(i=0;i<6;i++)  OV5640_WR_Reg(0x5384+i,OV5640_SATURATION_TBL[sat][i]);    
	OV5640_WR_Reg(0x538b, 0x98);
	OV5640_WR_Reg(0x538a, 0x01);
}

/**
  * @brief  Set the OV5640 camera Brightness Level.
  * @note   The brightness of OV5640 could be adjusted. Higher brightness will
  *         make the picture more bright. The side effect of higher brightness
  *         is the picture looks foggy.
  * @param  pObj  pointer to component object
  * @param  Level Value to be configured
  * @retval Component status
  */
void OV5640_SetBrightness(int32_t Level)
{
	 const uint8_t brightness_level[] = {0x40U, 0x30U, 0x20U, 0x10U, 0x00U, 0x10U, 0x20U, 0x30U, 0x40U};
	 uint8_t tmp;

	 tmp = 0xFF;
	 OV5640_WR_Reg(OV5640_ISP_CONTROL01, tmp);

	 tmp = brightness_level[Level + 4];
	 OV5640_WR_Reg(OV5640_SDE_CTRL7, tmp);

	 tmp = 0x04;
	 OV5640_WR_Reg(OV5640_SDE_CTRL0, tmp);

	 if (Level < 0)
	 {
	   tmp = 0x01;
	   OV5640_WR_Reg(OV5640_SDE_CTRL8, tmp);
	 }
	 else
	 {
	   tmp = 0x09;
	   OV5640_WR_Reg(OV5640_SDE_CTRL8, tmp);
	 }
}

//Contrast:
//     contrast:  0 - 6
void OV5640_Contrast(uint8_t contrast)
{
	uint8_t reg0val=0X00;
	uint8_t reg1val=0X20;
	switch(contrast)
	{
		case 0://-3
			reg1val=reg0val=0X14;	 	 
			break;	
		case 1://-2
			reg1val=reg0val=0X18; 	 
			break;	
		case 2://-1
			reg1val=reg0val=0X1C;	 
			break;	
		case 4://1
			reg0val=0X10;	 	 
			reg1val=0X24;	 	 
			break;	
		case 5://2
			reg0val=0X18;	 	 
			reg1val=0X28;	 	 
			break;	
		case 6://3
			reg0val=0X1C;	 	 
			reg1val=0X2C;	 	 
			break;	
	} 

	OV5640_WR_Reg(0x5585,reg0val);
	OV5640_WR_Reg(0x5586,reg1val); 
}
// Sharpness:
//    sharp: 0 - 33   (0: close , 33: auto , other: Sharpness)

void OV5640_Sharpness(uint8_t sharp)
{
	if(sharp<33)
	{
		OV5640_WR_Reg(0x5308,0x65);
		OV5640_WR_Reg(0x5302,sharp);
	}else	// auto
	{
		OV5640_WR_Reg(0x5308,0x25);
		OV5640_WR_Reg(0x5300,0x08);
		OV5640_WR_Reg(0x5301,0x30);
		OV5640_WR_Reg(0x5302,0x10);
		OV5640_WR_Reg(0x5303,0x00);
		OV5640_WR_Reg(0x5309,0x08);
		OV5640_WR_Reg(0x530a,0x30);
		OV5640_WR_Reg(0x530b,0x04);
		OV5640_WR_Reg(0x530c,0x06);
	}
	
}

void OV5640_SetColorEffect(uint32_t Effect)
{ 

	  uint8_t tmp;


	  switch (Effect)
	  {
	    case OV5640_COLOR_EFFECT_BLUE:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x18;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      tmp = 0xA0;
	      OV5640_WR_Reg(OV5640_SDE_CTRL3,tmp);

	      tmp = 0x40;
	      OV5640_WR_Reg(OV5640_SDE_CTRL4,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_RED:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x18;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      tmp = 0x80;
	      OV5640_WR_Reg(OV5640_SDE_CTRL3,tmp);

	      tmp = 0xC0;
	      OV5640_WR_Reg(OV5640_SDE_CTRL4,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_GREEN:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x18;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      tmp = 0x60;
	      OV5640_WR_Reg(OV5640_SDE_CTRL3,tmp);

	      tmp = 0x60;
	      OV5640_WR_Reg(OV5640_SDE_CTRL4,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_BW:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x18;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      tmp = 0x80;
	      OV5640_WR_Reg(OV5640_SDE_CTRL3,tmp);

	      tmp = 0x80;
	      OV5640_WR_Reg(OV5640_SDE_CTRL4,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_SEPIA:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x18;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      tmp = 0x40;
	      OV5640_WR_Reg(OV5640_SDE_CTRL3,tmp);

	      tmp = 0xA0;
	      OV5640_WR_Reg(OV5640_SDE_CTRL4,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_NEGATIVE:
	      tmp = 0xFF;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x40;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      break;

	    case OV5640_COLOR_EFFECT_NONE:
	    default :
	      tmp = 0x7F;
	      OV5640_WR_Reg(OV5640_ISP_CONTROL01,tmp);

	      tmp = 0x00;
	      OV5640_WR_Reg(OV5640_SDE_CTRL0,tmp);

	      break;
	  }

	OV5640_WR_Reg(0x5003,0x08);
}

// Flash Lamp
//  sw:  0: off
//       1:  on
void OV5640_Flash_Lamp(uint8_t sw)
{
	OV5640_WR_Reg(0x3016,0X02);
	OV5640_WR_Reg(0x301C,0X02); 
	if(sw)OV5640_WR_Reg(0X3019,0X02); 
	else OV5640_WR_Reg(0X3019,0X00);
} 

/**
  * @brief  Set OV5640 camera PCLK, HREF and VSYNC Polarities
  * @param  pObj  pointer to component object
  * @param  PclkPolarity Polarity of the PixelClock
  * @param  HrefPolarity Polarity of the Href
  * @param  VsyncPolarity Polarity of the Vsync
  * @retval Component status
  */
int32_t OV5640_SetPolarities(uint32_t PclkPolarity, uint32_t HrefPolarity, uint32_t VsyncPolarity)
{
  uint8_t tmp;

  if (((PclkPolarity != OV5640_POLARITY_PCLK_LOW) && (PclkPolarity != OV5640_POLARITY_PCLK_HIGH)) ||
      ((HrefPolarity != OV5640_POLARITY_HREF_LOW) && (HrefPolarity != OV5640_POLARITY_HREF_HIGH)) ||
      ((VsyncPolarity != OV5640_POLARITY_VSYNC_LOW) && (VsyncPolarity != OV5640_POLARITY_VSYNC_HIGH)))
  {
    return 0;
  }
  else
  {
    tmp = (uint8_t)(PclkPolarity << 5U) | (HrefPolarity << 1U) | VsyncPolarity;
	OV5640_WR_Reg(OV5640_POLARITY_CTRL,tmp); //launch group 3
  }

  return 1;
}

/**
  * @brief  Set OV5640 camera Pixel Format.
  * @param  pObj  pointer to component object
  * @param  PixelFormat pixel format to be configured
  * @retval Component status
  */
uint8_t OV5640_SetResolution(uint16_t offx,uint16_t offy,uint32_t Resolution)
{
	  uint32_t index;
	  uint8_t tmp;
	  /* Initialization sequence for 1080p resolution (1920x1080)*/
	  static const uint16_t OV5640_1280x800p[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x05},
		{OV5640_TIMING_DVPHO_LOW, 0x00},
		{OV5640_TIMING_DVPVO_HIGH, 0x02},
		{OV5640_TIMING_DVPVO_LOW, 0xD0},
	  };

	  /* Initialization sequence for 1080p resolution (1920x1080)*/
	  static const uint16_t OV5640_1080p[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x07},
		{OV5640_TIMING_DVPHO_LOW, 0x80},
		{OV5640_TIMING_DVPVO_HIGH, 0x04},
		{OV5640_TIMING_DVPVO_LOW, 0x38},
	  };

	  /* Initialization sequence for WVGA resolution (800x480)*/
	  static const uint16_t OV5640_WVGA[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x03},
		{OV5640_TIMING_DVPHO_LOW, 0xC0},
		{OV5640_TIMING_DVPVO_HIGH, 0x02},
		{OV5640_TIMING_DVPVO_LOW, 0x20},
	  };

	  /* Initialization sequence for VGA resolution (640x480)*/
	  static const uint16_t OV5640_VGA[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x02},
		{OV5640_TIMING_DVPHO_LOW, 0x80},
		{OV5640_TIMING_DVPVO_HIGH, 0x01},
		{OV5640_TIMING_DVPVO_LOW, 0xE0},
	  };

	  /* Initialization sequence for 480x272 resolution */
	  static const uint16_t OV5640_480x272[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x01},
		{OV5640_TIMING_DVPHO_LOW, 0xE0},
		{OV5640_TIMING_DVPVO_HIGH, 0x01},
		{OV5640_TIMING_DVPVO_LOW, 0x10},
	  };

	  /* Initialization sequence for QVGA resolution (320x240) */
	  static const uint16_t OV5640_QVGA[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x01},
		{OV5640_TIMING_DVPHO_LOW, 0x40},
		{OV5640_TIMING_DVPVO_HIGH, 0x00},
		{OV5640_TIMING_DVPVO_LOW, 0xF0},
	  };

	  /* Initialization sequence for QQVGA resolution (160x120) */
	  static const uint16_t OV5640_QQVGA[][2] =
	  {
		{OV5640_TIMING_DVPHO_HIGH, 0x00},
		{OV5640_TIMING_DVPHO_LOW, 0xA0},
		{OV5640_TIMING_DVPVO_HIGH, 0x00},
		{OV5640_TIMING_DVPVO_LOW, 0x78},
	  };

	  switch (Resolution)
	     {
	       case OV5640_R160x120:
	         for (index = 0; index < (sizeof(OV5640_QQVGA) / 4U); index++)
	         {
	             tmp = (uint8_t)OV5640_QQVGA[index][1];
	        	 OV5640_WR_Reg(OV5640_QQVGA[index][0],tmp);
	         }
	         break;
	       case OV5640_R320x240:
	         for (index = 0; index < (sizeof(OV5640_QVGA) / 4U); index++)
	         {
	             tmp = (uint8_t)OV5640_QVGA[index][1];
	        	 OV5640_WR_Reg(OV5640_QVGA[index][0],tmp);
	         }
	         break;
	       case OV5640_R480x272:
	         for (index = 0; index < (sizeof(OV5640_480x272) / 4U); index++)
	         {
	             tmp = (uint8_t)OV5640_480x272[index][1];
	        	 OV5640_WR_Reg(OV5640_480x272[index][0],tmp);
	         }
	         break;
	       case OV5640_R640x480:
	         for (index = 0; index < (sizeof(OV5640_VGA) / 4U); index++)
	         {
	             tmp = (uint8_t)OV5640_VGA[index][1];
	        	 OV5640_WR_Reg(OV5640_VGA[index][0],tmp);
	         }
	         break;
	       case OV5640_R800x480:
	         for (index = 0; index < (sizeof(OV5640_WVGA) / 4U); index++)
	         {
	             tmp = (uint8_t)OV5640_WVGA[index][1];
	        	 OV5640_WR_Reg(OV5640_WVGA[index][0],tmp);
	         }
	         break;
	       case OV5640_R1920x1080:
			 for (index = 0; index < (sizeof(OV5640_1080p) / 4U); index++)
			 {
				 tmp = (uint8_t)OV5640_1080p[index][1];
				 OV5640_WR_Reg(OV5640_1080p[index][0],tmp);
			 }
			 break;
	       case OV5640_R1280x800:
			 for (index = 0; index < (sizeof(OV5640_1280x800p) / 4U); index++)
			 {
				 tmp = (uint8_t)OV5640_1280x800p[index][1];
				 OV5640_WR_Reg(OV5640_1280x800p[index][0],tmp);
			 }
			 break;
	       default:
	         return 1;
	         break;
	     }

		  OV5640_WR_Reg(0x3810,offy>>8);
		  OV5640_WR_Reg(0x3811,offy&0xff);

		  OV5640_WR_Reg(0x3812,offx>>8);
		  OV5640_WR_Reg(0x3813,offx&0xff);

		return 0;
}


uint8_t OV5640_Focus_Init(void)
{ 
	uint16_t i; 
	uint16_t addr=0x8000;
	uint8_t state=0x8F;
	OV5640_WR_Reg(0x3000, 0x20);	//reset 	 
	for(i=0;i<sizeof(OV5640_AF_Config);i++) 
	{
		OV5640_WR_Reg(addr,OV5640_AF_Config[i]);
		addr++;
	}  
	OV5640_WR_Reg(0x3022,0x00);
	OV5640_WR_Reg(0x3023,0x00);
	OV5640_WR_Reg(0x3024,0x00);
	OV5640_WR_Reg(0x3025,0x00);
	OV5640_WR_Reg(0x3026,0x00);
	OV5640_WR_Reg(0x3027,0x00);
	OV5640_WR_Reg(0x3028,0x00);
	OV5640_WR_Reg(0x3029,0x7f);
	OV5640_WR_Reg(0x3000,0x00); 
	i=0;
	do
	{
		state=OV5640_RD_Reg(0x3029);	
		HAL_Delay(5);
		i++;
		if(i>1000)return 1;
	}while(state!=0x70); 
	return 0;    
}  

uint8_t OV5640_Auto_Focus(void)
{
	uint8_t temp=0;   
	uint16_t retry=0; 
	OV5640_WR_Reg(0x3023,0x01);
	OV5640_WR_Reg(0x3022,0x08);
	do 
	{
		temp=OV5640_RD_Reg(0x3023); 
		retry++;
		if(retry>1000)return 2;
		HAL_Delay(5);
	} while(temp!=0x00);   
	OV5640_WR_Reg(0x3023,0x01);
	OV5640_WR_Reg(0x3022,0x04);
	retry=0;
	do 
	{
		temp=OV5640_RD_Reg(0x3023); 
		retry++;
		if(retry>1000)return 2;
		HAL_Delay(5);
	}while(temp!=0x00);
	return 0;
} 

//
//void jpeg_test(uint8_t jpg_size)
//{
//        HAL_DCMI_Stop(&hdcmi);
//
// 	OV5640_JPEG_Mode();
// 	OV5640_OutSize_Set(4, 0, jpeg_size_tbl[jpg_size][0],jpeg_size_tbl[jpg_size][1]);
//
//        OV5640_WR_Reg(0x3035,0X41); // slow down OV5640 clocks
//        OV5640_WR_Reg(0x3036,0x68);
//
//        /* DCMI DMA DeInit */
//        HAL_DMA_DeInit(&hdma_dcmi);
//
//        /* DCMI DMA Init */
//        /* DCMI Init */
//        hdma_dcmi.Instance = DMA2_Stream1;
//        hdma_dcmi.Init.Channel = DMA_CHANNEL_1;
//        hdma_dcmi.Init.Direction = DMA_PERIPH_TO_MEMORY;
//        hdma_dcmi.Init.PeriphInc = DMA_PINC_DISABLE;
//        hdma_dcmi.Init.MemInc = DMA_MINC_ENABLE;
//        hdma_dcmi.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
//        hdma_dcmi.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
//        hdma_dcmi.Init.Mode = DMA_CIRCULAR;
//        hdma_dcmi.Init.Priority = DMA_PRIORITY_HIGH;
//        hdma_dcmi.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
//        hdma_dcmi.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
//        hdma_dcmi.Init.MemBurst = DMA_MBURST_SINGLE;
//        hdma_dcmi.Init.PeriphBurst = DMA_PBURST_SINGLE;
//        if (HAL_DMA_Init(&hdma_dcmi) != HAL_OK)
//        {
//        _Error_Handler(__FILE__, __LINE__);
//        }
//
//        __HAL_LINKDMA(&hdcmi,DMA_Handle,hdma_dcmi);
//
//        __HAL_DCMI_ENABLE_IT(&hdcmi,DCMI_IT_FRAME);
//
//        /* Start the Camera capture */
//        HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_CONTINUOUS, (uint32_t)jpeg_data_buf, jpeg_buf_size/4 );
//
//        jpeg_mode = 1;
//
//        while(1)
//        {
//
//        }
//}
//
//void rgb565_test(void)
//{
//        HAL_DCMI_Stop(&hdcmi);
//
//        jpeg_mode = 0;
//
//	OV5640_RGB565_Mode();
//        OV5640_OutSize_Set(4,0, XSIZE , YSIZE);
//
//        BSP_LCD_Init();
//        BSP_LCD_Clear(LCD_COLOR_BLACK);
//
//        /* Set image position */
//        ili9325_SetCursor(0, 0);
//        /* Prepare to write GRAM (0x22) */
//        LCD_IO_WriteReg(LCD_REG_34);
//
//        OV5640_WR_Reg(0x3035,0X51); // slow down OV5640 clocks ,adapt to the refresh rate of the LCD
//        OV5640_WR_Reg(0x3036,0X88);
//
//        /* DCMI DMA DeInit */
//        HAL_DMA_DeInit(&hdma_dcmi);
//
//        /* DCMI DMA Init */
//        /* DCMI Init */
//        hdma_dcmi.Instance = DMA2_Stream1;
//        hdma_dcmi.Init.Channel = DMA_CHANNEL_1;
//        hdma_dcmi.Init.Direction = DMA_PERIPH_TO_MEMORY;
//        hdma_dcmi.Init.PeriphInc = DMA_PINC_DISABLE;
//        hdma_dcmi.Init.MemInc = DMA_MINC_DISABLE;
//        hdma_dcmi.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
//        hdma_dcmi.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
//        hdma_dcmi.Init.Mode = DMA_CIRCULAR;
//        hdma_dcmi.Init.Priority = DMA_PRIORITY_HIGH;
//        hdma_dcmi.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
//        hdma_dcmi.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_HALFFULL;
//        hdma_dcmi.Init.MemBurst = DMA_MBURST_SINGLE;
//        hdma_dcmi.Init.PeriphBurst = DMA_PBURST_SINGLE;
//        if (HAL_DMA_Init(&hdma_dcmi) != HAL_OK)
//        {
//        _Error_Handler(__FILE__, __LINE__);
//        }
//
//        __HAL_LINKDMA(&hdcmi,DMA_Handle,hdma_dcmi);
//
//        /* Start the Camera capture */
//        HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_CONTINUOUS, (uint32_t)LCD_GRAM_ADDRESS, 1);
//
//        while(1)
//        {
//
//        }
//}
//
//void jpeg_dcmi_frame_callback(DMA_HandleTypeDef *_hdma)
//{
//        uint8_t *p;
//        uint32_t i=0,jpgstart=0,jpglen=0;
//        uint8_t  head=0;
//
//
//
//        HAL_DCMI_Stop(&hdcmi);
//
//        p=(uint8_t*)jpeg_data_buf;
//
//        for(i=0;i<jpeg_buf_size * 4; i++) //search for 0XFF 0XD8 and 0XFF 0XD9, get size of JPG
//        {
//                if((p[i]==0XFF)&&(p[i+1]==0XD8))
//                {
//                        jpgstart=i;
//                        head=1;	// Already found  FF D8
//                }
//                if((p[i]==0XFF)&&(p[i+1]==0XD9)&&head)  //search for FF D9
//                {
//                        jpglen=i-jpgstart+2;
//                        break;
//                }
//        }
//        if(jpglen)
//        {
//                p+=jpgstart;	// move to FF D8
//                for(i=0;i<jpglen;i++)	// send JPG
//                {
//                        USART1->DR=p[i];
//                        while((USART1->SR&0X40)==0);
//                }
//
//                printf("jpg_size :  %d \r\n" , jpglen);
//                //printf("jpgstart :  %d \r\n" , jpgstart);
//        }
//
//        HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_CONTINUOUS, (uint32_t)jpeg_data_buf, jpeg_buf_size/4);
//}
//
///**
//  * @brief  Frame Event callback.
//  * @param  None
//  * @retval None
//  */
//void HAL_DCMI_FrameEventCallback(DCMI_HandleTypeDef *hdcmi)
//{
//        if(jpeg_mode == 1)
//        {
//                jpeg_dcmi_frame_callback(&hdma_dcmi);
//        }
//
//        __HAL_DCMI_ENABLE_IT(hdcmi,DCMI_IT_FRAME);
//}



