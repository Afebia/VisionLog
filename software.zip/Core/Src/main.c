/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ff.h"            // FatFS definitions (_MAX_SS)
#include "ff_gen_drv.h"   // FATFS_LinkDriver
#include "ov5640.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* Global FatFS objects ------------------------------------------------------*/
FRESULT res;
FATFS fs;
FIL videoFile;
UINT bytesWritten;

/* Logical drive path (as defined in fatfs.h) */
extern char SDPath[4];    // e.g. "0:/"

//SD Kart Bilgiler
HAL_SD_CardInfoTypeDef info;

//FMC Status
HAL_StatusTypeDef status_fmc;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#pragma pack(push,1)
//typedef struct {
//  uint16_t bfType;      // 'BM'
//  uint32_t bfSize;      // file size
//  uint16_t bfReserved1;
//  uint16_t bfReserved2;
//  uint32_t bfOffBits;   // offset to pixel data (54)
//  uint32_t biSize;      // header size (40)
//  int32_t  biWidth;
//  int32_t  biHeight;
//  uint16_t biPlanes;    // must be 1
//  uint16_t biBitCount;  // bits per pixel (24)
//  uint32_t biCompression;
//  uint32_t biSizeImage; // image size (w*h*3)
//  uint32_t biXPelsPerMeter;
//  uint32_t biYPelsPerMeter;
//  uint32_t biClrUsed;
//  uint32_t biClrImportant;
//} BMPHeader;
//#pragma pack(pop)
//
//static uint8_t LUT_R[32];
//static uint8_t LUT_G[64];
//static uint8_t LUT_B[32];

uint32_t id;


/* Çözünürlük ve formati buradan kontrol edin */
#define IMG_W                 960
#define IMG_H                 544
#define PIXEL_BYTES           2
#define IMG_SIZE_BYTES        (IMG_W * IMG_H * PIXEL_BYTES)

/* SDRAM’de video buffer başlangıç adresi (örneğin 0xC0000000) */
#define SDRAM_FRAME_ADDR   ((uint32_t)0xC0000000)
/* SDRAM toplam boyutu 32 MB */
#define SDRAM_SIZE_BYTES   (32UL * 1024 * 1024)


/* Global flag’lar */
volatile uint32_t frame_counter = 0;
volatile bool dcmi_frame_done = false;
volatile bool gpio_triggered = false;

static int frame_idx = 0;
int dcmi_start;
int dcmi_time;
int sdcard_start;
int sdcard_time;

//int16_t data_i2s[WAV_WRITE_SAMPLE_COUNT];
//volatile int16_t sample_i2s;
//volatile uint8_t half_i2s;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

DCMI_HandleTypeDef hdcmi;
DMA_HandleTypeDef hdma_dcmi;

JPEG_HandleTypeDef hjpeg;
MDMA_HandleTypeDef hmdma_jpeg_outfifo_th;
MDMA_HandleTypeDef hmdma_jpeg_infifo_nf;

SD_HandleTypeDef hsd1;

SDRAM_HandleTypeDef hsdram1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_MDMA_Init(void);
static void MX_DCMI_Init(void);
static void MX_FMC_Init(void);
static void MX_SDMMC1_SD_Init(void);
static void MX_JPEG_Init(void);
/* USER CODE BEGIN PFP */
void SDRAM_ClearAll(void);
void SDRAM_ClearFrameBuf(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*
 * I2S Microphone Callback:
 */
//void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s)
//{
////	sample_i2s = data_i2s[0];
////	write2wave_file(((uint8_t*)data_i2s), WAV_WRITE_SAMPLE_COUNT);
//}

// EXTI Line9 External Interrupt ISR Handler CallBackFun
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == GPIO_PIN_10) // If The INT Source Is EXTI Line9 (A9 Pin)
    {
        gpio_triggered = (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_SET);
    }
}

/**
  * @brief  DCMI DMA Transfer Complete Callback
  *         Bu fonksiyon, SDRAM’in “Buffer1 → Buffer0�? yarı tampon sınırına
  *         ulaştığında tetiklenir (örneğin Buffer1 dolduğunda). O yüzden
  *         “fullBufferFull_flag�? true olur → main() o yarıyı SD’ya yazar.
  */
void HAL_DCMI_FrameEventCallback(DCMI_HandleTypeDef *hdcmi)
{
	  dcmi_frame_done = true;
	  frame_counter++;

	  __HAL_DCMI_CLEAR_FLAG(hdcmi, DCMI_FLAG_FRAMERI);

}



void HAL_DCMI_ErrorCallback(DCMI_HandleTypeDef *hdcmi)
{
    /* Herhangi bir DCMI hatası durumunda hata handler’a geç */
    Error_Handler();
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Configure The Vector Table address */
  SCB->VTOR = 0x08000000;

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_MDMA_Init();
  MX_DCMI_Init();
  MX_FMC_Init();
  MX_SDMMC1_SD_Init();
  MX_JPEG_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */

//  for (int i = 0; i < 32; i++) {
//    LUT_R[i] = (uint8_t)((i * 255) / 31);
//    LUT_B[i] = (uint8_t)((i * 255) / 31);
//  }
//  for (int i = 0; i < 64; i++) {
//    LUT_G[i] = (uint8_t)((i * 255) / 63);
//  }
  /* 1) SDRAM’i tamamen temizle (opsiyonel ama tavsiye edilir) */
   SDRAM_ClearAll();

   /* 2) OV5640’ı başlat ve 320×240 RGB565 moduna getir */
   while (OV5640_Init()) {
       printf("OV5640 init failed! Retry...\r\n");
       HAL_Delay(500);
   }

   // sensör inicfg.c içinde OV5640_Init’den sonra ekleyin:
   OV5640_WR_Reg(0x5580, 0x02); // SDE: Y filtresi enable
   OV5640_WR_Reg(0x5583, 0x40); // Y thresh
   OV5640_WR_Reg(0x5584, 0x10); // UV thresh
   OV5640_WR_Reg(0x5585, 0x06); // filter strength
   OV5640_WR_Reg(0x5586, 0x10); // filter bias
   // SDE on/off kontrol, eğer REG 0x5001 bit0=1 ise SDE aktif:
   uint8_t v = OV5640_RD_Reg(0x5001);
   OV5640_WR_Reg(0x5001, v | 0x01);

   OV5640_EnableDVPMode();

   OV5640_SetPixelFormat(OV5640_RGB565);
   OV5640_SetResolution(0, 0, OV5640_R800x480);

   /* HREF/VSYNC/PCLK polariteleri AN5020’a uygun: */
   OV5640_SetPolarities(
       OV5640_POLARITY_PCLK_HIGH,    // PCLK pozitif kenar
       OV5640_POLARITY_HREF_LOW,     // HREF “satır bitti�? low→high
       OV5640_POLARITY_VSYNC_LOW     // VSYNC “kare bitti�? low→high
   );
   OV5640_SetPCLK(OV5640_PCLK_48M);



   /* Otomatik pozlama/gölgelenme: */
//   OV5640_Light_Mode(OV5640_LIGHT_SUNNY);
//   OV5640_Color_Saturation(3);
//   OV5640_SetBrightness(3);
//   OV5640_Contrast(5);
//   OV5640_Exposure(3);
//   OV5640_Sharpness(33);

   // 2) disk_initialize kontrol
   DSTATUS ds = disk_initialize(0);
   if (ds != 0) {
     printf("disk_initialize failed (0x%02X)\r\n", ds);
   }
   /* 3) SD kartı bağla, yoksa formatla */
   int retries = 10;
   for (int i = 0; i < retries; i++) {
       res = f_mount(&fs, SDPath, 1);
       if (res == FR_OK) break;
       printf("f_mount attempt %d failed: %d\r\n", i+1, res);
       HAL_Delay(100);
   }
   if (res == FR_NO_FILESYSTEM) {
       static BYTE work[_MAX_SS];
       if (f_mkfs(SDPath, FM_ANY, 0, work, sizeof(work)) != FR_OK) {
           Error_Handler();
       }
       res = f_mount(&fs, SDPath, 1);
   }
   if (res != FR_OK) {
       printf("f_mount final failed: %d\r\n", res);
       Error_Handler();
   }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


	  while (!gpio_triggered) {
	 	            __WFI();
	 	        }

	 	        /* HIGH → 1 Hz snap loop */
	 	        while (gpio_triggered)
	 	        {

	 	            /* 1) DCMI snapshot */
					dcmi_frame_done = false;
					__HAL_DCMI_ENABLE_IT(&hdcmi, DCMI_IT_FRAME);
					if (HAL_DCMI_Start_DMA(&hdcmi,
										   DCMI_MODE_SNAPSHOT,
										   SDRAM_FRAME_ADDR,
										   IMG_SIZE_BYTES/4) != HAL_OK)
						Error_Handler();
					while (!dcmi_frame_done) { __WFI(); }
					HAL_DCMI_Stop(&hdcmi);


				   /* 4’) SD’ye BMP olarak yaz */
//				   FIL f;
//				   char name[32];
//				   snprintf(name,sizeof(name),"0:/Frame_%03d.raw", frame_idx++);
//				   if(f_open(&f, name, FA_CREATE_ALWAYS|FA_WRITE)!=FR_OK) Error_Handler();

//	 	          /* BMP header’ını doldur */
//	 	          BMPHeader hdr = {0};
//	 	          hdr.bfType      = 0x4D42;               // 'BM'
//	 	          hdr.bfOffBits   = sizeof(BMPHeader);
//	 	          hdr.biSize      = 40;
//	 	          hdr.biWidth     = IMG_W;
//	 	          hdr.biHeight    = -IMG_H;               // negatif = top-down
//	 	          hdr.biPlanes    = 1;
//	 	          hdr.biBitCount  = 24;
//	 	          hdr.biSizeImage = IMG_W*IMG_H*3;
//	 	          hdr.bfSize      = hdr.bfOffBits + hdr.biSizeImage;
//
//	 	          UINT bw;
//	 	          if(f_write(&f, &hdr, sizeof(hdr), &bw)!=FR_OK || bw!=sizeof(hdr)) Error_Handler();

//	 	          /* her satır için lookup table’lı dönüştür ve yaz */
//	 	          uint8_t lineBuf[IMG_W*3];
//	 	          uint16_t *src = (uint16_t*)SDRAM_FRAME_ADDR;
//	 	          for(int y = 0; y < IMG_H; y++) {
//	 	            for(int x = 0; x < IMG_W; x++) {
//	 	              uint16_t pix = src[y*IMG_W + x];
//	 	              uint8_t r = LUT_R[ (pix >> 11)        & 0x1F ];
//	 	              uint8_t g = LUT_G[ (pix >> 5)  & 0x3F ];
//	 	              uint8_t b = LUT_B[  pix        & 0x1F ];
//	 	              lineBuf[x*3 + 0] = b;
//	 	              lineBuf[x*3 + 1] = g;
//	 	              lineBuf[x*3 + 2] = r;
//	 	            }
//	 	            if(f_write(&f, lineBuf, IMG_W*3, &bw)!=FR_OK || bw!=(IMG_W*3)) Error_Handler();
//	 	          }
					 FIL f;
					 char name[32];
					 snprintf(name, sizeof(name),"0:/Frame_%03d.raw", frame_idx++);
					 if (f_open(&f, name, FA_WRITE|FA_CREATE_ALWAYS) != FR_OK) Error_Handler();
					 UINT bw;
					 uint8_t *p = (uint8_t *) SDRAM_FRAME_ADDR;
					 if (f_write(&f, p, IMG_SIZE_BYTES, &bw) != FR_OK || bw != IMG_SIZE_BYTES)
					   Error_Handler();
					 f_sync(&f);
					 f_close(&f);
					 HAL_Delay(200);

					 SDRAM_ClearFrameBuf();



	 	        }


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 2;
  RCC_OscInitStruct.PLL.PLLN = 64;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 4;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_HSI, RCC_MCODIV_4);
}

/**
  * @brief DCMI Initialization Function
  * @param None
  * @retval None
  */
static void MX_DCMI_Init(void)
{

  /* USER CODE BEGIN DCMI_Init 0 */

  /* USER CODE END DCMI_Init 0 */

  /* USER CODE BEGIN DCMI_Init 1 */

  /* USER CODE END DCMI_Init 1 */
  hdcmi.Instance = DCMI;
  hdcmi.Init.SynchroMode = DCMI_SYNCHRO_HARDWARE;
  hdcmi.Init.PCKPolarity = DCMI_PCKPOLARITY_RISING;
  hdcmi.Init.VSPolarity = DCMI_VSPOLARITY_LOW;
  hdcmi.Init.HSPolarity = DCMI_HSPOLARITY_LOW;
  hdcmi.Init.CaptureRate = DCMI_CR_ALL_FRAME;
  hdcmi.Init.ExtendedDataMode = DCMI_EXTEND_DATA_8B;
  hdcmi.Init.JPEGMode = DCMI_JPEG_ENABLE;
  hdcmi.Init.ByteSelectMode = DCMI_BSM_ALL;
  hdcmi.Init.ByteSelectStart = DCMI_OEBS_ODD;
  hdcmi.Init.LineSelectMode = DCMI_LSM_ALL;
  hdcmi.Init.LineSelectStart = DCMI_OELS_ODD;
  if (HAL_DCMI_Init(&hdcmi) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DCMI_Init 2 */
  HAL_NVIC_SetPriority(DCMI_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DCMI_IRQn);
  /* USER CODE END DCMI_Init 2 */

}

/**
  * @brief JPEG Initialization Function
  * @param None
  * @retval None
  */
static void MX_JPEG_Init(void)
{

  /* USER CODE BEGIN JPEG_Init 0 */

  /* USER CODE END JPEG_Init 0 */

  /* USER CODE BEGIN JPEG_Init 1 */

  /* USER CODE END JPEG_Init 1 */
  hjpeg.Instance = JPEG;
  if (HAL_JPEG_Init(&hjpeg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN JPEG_Init 2 */

  /* USER CODE END JPEG_Init 2 */

}

/**
  * @brief SDMMC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDMMC1_SD_Init(void)
{

  /* USER CODE BEGIN SDMMC1_Init 0 */

  /* USER CODE END SDMMC1_Init 0 */

  /* USER CODE BEGIN SDMMC1_Init 1 */

  /* USER CODE END SDMMC1_Init 1 */
  hsd1.Instance = SDMMC1;
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_FALLING;
  hsd1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hsd1.Init.BusWide = SDMMC_BUS_WIDE_4B;
  hsd1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
  hsd1.Init.ClockDiv = 6;
  /* USER CODE BEGIN SDMMC1_Init 2 */
  // if a uSDcard is present initialize everything

     __HAL_RCC_SDMMC1_FORCE_RESET();
     __HAL_RCC_SDMMC1_RELEASE_RESET();

     HAL_Delay(2);

     SDMMC_PowerState_Cycle(SDMMC1);
     HAL_SD_MspInit(&hsd1);

     HAL_Delay(2);
     HAL_Delay(1);

     (void)SDMMC_PowerState_OFF(SDMMC1);
     HAL_Delay(2);
     if (HAL_SD_Init(&hsd1) != HAL_OK) // init the uSD card
   	  {
 	  	  Error_Handler();
   	  }

     if (HAL_SD_GetCardInfo(&hsd1, &info) == HAL_OK) {
         printf("Card capacity: %lu MB, Block size: %lu bytes\r\n",
                (info.LogBlockNbr * info.LogBlockSize) / (1024*1024),
                info.LogBlockSize);
     }

  /* USER CODE END SDMMC1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);

}

/**
  * Enable MDMA controller clock
  */
static void MX_MDMA_Init(void)
{

  /* MDMA controller clock enable */
  __HAL_RCC_MDMA_CLK_ENABLE();
  /* Local variables */

  /* MDMA interrupt initialization */
  /* MDMA_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(MDMA_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(MDMA_IRQn);

}

/* FMC initialization function */
static void MX_FMC_Init(void)
{

  /* USER CODE BEGIN FMC_Init 0 */

  /* USER CODE END FMC_Init 0 */

  FMC_SDRAM_TimingTypeDef SdramTiming = {0};

  /* USER CODE BEGIN FMC_Init 1 */

  /* USER CODE END FMC_Init 1 */

  /** Perform the SDRAM1 memory initialization sequence
  */
  hsdram1.Instance = FMC_SDRAM_DEVICE;
  /* hsdram1.Init */
  hsdram1.Init.SDBank = FMC_SDRAM_BANK1;
  hsdram1.Init.ColumnBitsNumber = FMC_SDRAM_COLUMN_BITS_NUM_9;
  hsdram1.Init.RowBitsNumber = FMC_SDRAM_ROW_BITS_NUM_13;
  hsdram1.Init.MemoryDataWidth = FMC_SDRAM_MEM_BUS_WIDTH_16;
  hsdram1.Init.InternalBankNumber = FMC_SDRAM_INTERN_BANKS_NUM_4;
  hsdram1.Init.CASLatency = FMC_SDRAM_CAS_LATENCY_2;
  hsdram1.Init.WriteProtection = FMC_SDRAM_WRITE_PROTECTION_DISABLE;
  hsdram1.Init.SDClockPeriod = FMC_SDRAM_CLOCK_PERIOD_2;
  hsdram1.Init.ReadBurst = FMC_SDRAM_RBURST_ENABLE;
  hsdram1.Init.ReadPipeDelay = FMC_SDRAM_RPIPE_DELAY_0;
  /* SdramTiming */
  SdramTiming.LoadToActiveDelay = 2;
  SdramTiming.ExitSelfRefreshDelay = 8;
  SdramTiming.SelfRefreshTime = 5;
  SdramTiming.RowCycleDelay = 6;
  SdramTiming.WriteRecoveryTime = 3;
  SdramTiming.RPDelay = 2;
  SdramTiming.RCDDelay = 2;

  if (HAL_SDRAM_Init(&hsdram1, &SdramTiming) != HAL_OK)
  {
    Error_Handler( );
  }

  HAL_SetFMCMemorySwappingConfig(FMC_SWAPBMAP_SDRAMB2);

  /* USER CODE BEGIN FMC_Init 2 */
  /* SDRAM init komut dizisi */
  FMC_SDRAM_CommandTypeDef Command;
  /* 1) CLK Enable */
  Command.CommandMode       = FMC_SDRAM_CMD_CLK_ENABLE;
  Command.CommandTarget     = FMC_SDRAM_CMD_TARGET_BANK1;
  Command.AutoRefreshNumber = 1;
  HAL_SDRAM_SendCommand(&hsdram1, &Command, 0x1000);
  HAL_Delay(1);
  /* 2) PALL */
  Command.CommandMode       = FMC_SDRAM_CMD_PALL;
  Command.CommandTarget     = FMC_SDRAM_CMD_TARGET_BANK1;
  HAL_SDRAM_SendCommand(&hsdram1, &Command, 0x1000);
  /* 3) Auto-refresh */
  Command.CommandMode       = FMC_SDRAM_CMD_AUTOREFRESH_MODE;
  Command.CommandTarget     = FMC_SDRAM_CMD_TARGET_BANK1;
  Command.AutoRefreshNumber = 8;
  HAL_SDRAM_SendCommand(&hsdram1, &Command, 0x1000);
  /* 4) Load Mode Register */
  Command.CommandMode            = FMC_SDRAM_CMD_LOAD_MODE;
  Command.CommandTarget          = FMC_SDRAM_CMD_TARGET_BANK1;
  /* Mode register: Burst length=1, CAS Lat=2, Normal operation */
  Command.ModeRegisterDefinition = 0x0200;
  HAL_SDRAM_SendCommand(&hsdram1, &Command, 0x1000);
  /* 5) Refresh Rate programla (168 MHz/64 * 7.81µs) ≈ 1542 */
  HAL_SDRAM_ProgramRefreshRate(&hsdram1, 1542);

  /* USER CODE END FMC_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CAM_PWDN_GPIO_Port, CAM_PWDN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_SET);

  /*Configure GPIO pin : CAM_PWDN_Pin */
  GPIO_InitStruct.Pin = CAM_PWDN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CAM_PWDN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_card_CS_Pin */
  GPIO_InitStruct.Pin = SD_card_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(SD_card_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/**
  * @brief  SDRAM’in tamamını sıfırlar (32 MB)
  */
void SDRAM_ClearAll(void)
{
    uint32_t *p = (uint32_t*)SDRAM_FRAME_ADDR;
    uint32_t words = SDRAM_SIZE_BYTES / 4U;
    for (uint32_t i = 0; i < words; i++) {
        p[i] = 0;
    }
}

void SDRAM_ClearFrameBuf(void)
{
    uint32_t *p = (uint32_t*)SDRAM_FRAME_ADDR;
    uint32_t words = IMG_SIZE_BYTES / 4;

    for (uint32_t i = 0; i < words; ++i)
    {
        p[i] = 0x00000000;
    }
}
/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER1;
  MPU_InitStruct.BaseAddress = 0x08000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_2MB;
  MPU_InitStruct.SubRegionDisable = 0x0;
  MPU_InitStruct.AccessPermission = MPU_REGION_PRIV_RO;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_ENABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_CACHEABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER2;
  MPU_InitStruct.BaseAddress = 0xC0000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_32MB;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL1;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
